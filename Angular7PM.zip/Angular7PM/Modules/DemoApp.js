var app = angular.module('DemoApp',[]);
app.controller('HomeController',function($scope) {
   $scope.title = "Home Page";
});
app.controller('ContactController',function($scope) {
    $scope.title = "Contact Page";
    $scope.address = "Naresh IT | Hyderbad | 040-288282";
});