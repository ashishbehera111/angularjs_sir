var mysql=require("mysql");
var con=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'12345',
    database:'angulardb'
});
con.connect(function(err){
    if(!err)
    {
        console.log('connected');
    }
    else{
        console.log(err);
    }
});