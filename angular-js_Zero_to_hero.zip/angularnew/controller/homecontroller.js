app.controller('homecontroller',function($scope){
    $scope.title="Naresh IT |Home";
});