var express=require("express");
var app=express();
app.get('/',function(reg,res){
    res.send('Request for index page ');
});
app.get('/products',function(req,res){
    res.send('Request for product page');
});
app.get('/c*t',function(req,res){
    res.send('Request for page like contact(c-t)')
});
app.post('/addproduct',function(req,res){
   res.send('post for aadding products');

});
app.put('/updateproduct',function(req,res){
    res.send('Put for update product')
});
app.delete('/deleteProduct',function(req,res){
    res.send('Delete for Delete products')
});
app.listen(8080);
console.log('server Started');