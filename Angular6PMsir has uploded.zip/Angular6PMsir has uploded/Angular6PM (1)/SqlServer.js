var sql = require("mssql");

var config = {
    user: 'sa',
    password: '123',
    server: 'localhost',
    database: 'ngprojectdb'
};

sql.connect(config, function (err) {
    if (err)
        console.log(err);
    else
    {
        console.log("Connected...");
        var request = new sql.Request();
        request.query('select * from tblproducts', function (err, recordset) {

            if (err) console.log(err)

            // send records as a response
            console.log(recordset);

        });
    }
});