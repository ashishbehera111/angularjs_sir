// Import Module
var http = require('http');
var fs = require('fs');

http.createServer(function (request, response) {
    var help = fs.readFileSync('help.txt');
    response.end(help.toString());
}).listen(8080);

console.log('Server Started on http://127.0.0.1:8080');