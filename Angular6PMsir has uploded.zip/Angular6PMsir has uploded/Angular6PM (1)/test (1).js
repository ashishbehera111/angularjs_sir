/**
 * Created by Administrator on 6/11/2018.
 */
var x=5;
var y=2;
var z= x*y;
console.log("Z=" + z);