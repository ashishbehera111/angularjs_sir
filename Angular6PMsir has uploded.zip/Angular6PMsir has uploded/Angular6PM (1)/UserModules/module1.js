var app1 = angular.module('Module1',[])
app1.controller('controller1');
app1.filter('filter1');
app1.service('service1');

