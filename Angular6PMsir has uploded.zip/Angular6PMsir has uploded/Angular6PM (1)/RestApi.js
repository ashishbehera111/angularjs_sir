var mysql = require("mysql");
var express = require("express");
var bodyParser = require("body-parser");

var app = express();
app.use(express.static('MEAN'))

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'1234',
    database:'ngprojectdb'
});

app.get('/',function (req, res) {
    res.redirect('MEAN/Index.html');
})

con.connect();
app.get('/Products',function (req, res) {
    con.query('Select * from tblProducts',function (err,rows,fields) {
        res.send(rows);
    })
})

app.post('/addProduct',function (req, res) {
    var data ={
        ProductId:req.body.ProductId,
        Name:req.body.Name,
        Price:req.body.Price,
        Mfd:new Date(req.body.Mfd)
    }
    con.query('Insert Into tblProducts SET ?',data,function (err) {
        if(!err)
            console.log('Record Inserted');
    })
})


app.listen(8080);
console.log('Server Started');