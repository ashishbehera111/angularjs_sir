var app = angular.module('app1',[]);
app.value('price',4000);