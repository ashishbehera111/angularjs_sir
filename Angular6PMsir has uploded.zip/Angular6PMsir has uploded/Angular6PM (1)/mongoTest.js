var express= require('express');
var MongoClient = require('mongodb').MongoClient;

var app=express();

var url = "mongodb://localhost:27017/";

app.get('/Products', function (req, res) {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("ngprojectdb");
        dbo.collection("tblproducts").find({}).toArray(function(err,
                                                                  result) {
            if (err) throw err;
            res.send(result);
            db.close();
        });
    });
});
app.listen(8080);
console.log('Server Started');

