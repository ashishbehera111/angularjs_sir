var mysql = require('mysql');
var express = require('express');

var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'1234',
    database:'ngprojectdb'
});

var app=express();

app.get('/Products', function (req, res) {
    con.connect();
    con.query('Select * from tblProducts',function (err, rows, fields) {
        console.log(rows);
        res.send(rows);
    })
});
app.listen(8080);
console.log('Server Started');


