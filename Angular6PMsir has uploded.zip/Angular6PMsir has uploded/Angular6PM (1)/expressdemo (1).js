var express = require('express');
var fs = require('fs');

var app=express();

app.get('/',function (req, res) {
    res.send('Main Page Accessed..');
});

app.get('/help',function (req, res) {
    var data = fs.readFileSync('help.txt');
    res.send(data.toString());
});

app.get('/a*t',function (req, res) {
    res.send('Request for Page with name starting with A and ending with T');
});

app.post('/Insert',function (req, res) {
    res.send('POST to Insert or Submit Data to server');
});

app.delete('/Delete',function (req, res) {
    res.send('Delete to remove resource from server');
})

app.listen(8080);
console.log('Server Started..');