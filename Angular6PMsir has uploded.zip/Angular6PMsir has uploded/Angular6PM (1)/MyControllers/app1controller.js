app.controller('app1controller',function ($scope) {
    $scope.msg="Welcome to Angular";
});
