var mysql = require('mysql')

var con = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'1234',
    database:'ngprojectdb'
});

con.connect();

var data={
    ProductId:5,
    Name:'Fastrack Watch',
    Price:4500.50,
    Mfd:new Date('2018/02/12')
};

con.query('Insert Into tblProducts SET ?',data,function (err) {
    if(!err)
    {
        console.log('Record Inserted');
    }
    else
    {
        console.log(err);
    }
})
