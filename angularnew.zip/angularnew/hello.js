var name="john";
console.log("Hello!"+name+"welcome to Node js");