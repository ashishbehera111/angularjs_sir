app.controller('contactcontroller',function($scope){
    $scope .title="contact us";
   $scope.address="naresh IT | hyd |hr@naresh.in"
});