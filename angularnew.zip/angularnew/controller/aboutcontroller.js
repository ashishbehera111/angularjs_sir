app.controller('Aboutcontroller',function($scope){
    $scope.title="About us";
});